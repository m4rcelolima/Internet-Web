# Internet-Web

https://htmlpreview.github.io/?
Usar o link acima antes do link para o arquivo html que quer abrir.
